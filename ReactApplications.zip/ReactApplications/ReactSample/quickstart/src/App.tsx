// import the datepickerComponent
import { DatePickerComponent } from '@syncfusion/ej2-react-calendars';
import * as React from 'react';
import './App.css';

export default class App extends React.Component<{}, {}> {
   public render() {
        return <DatePickerComponent id="datepicker" width='270px'/>;
    }
}